list1 =[7, 5, 4, 8]
for i in reversed(list1):
    print(i)