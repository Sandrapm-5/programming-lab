str1 = input("enter the string1:")
str2 = input("enter the  string2:")
print(str1.replace(str1[0], str2[0])+''+str2.replace(str2[0],str1[0]))