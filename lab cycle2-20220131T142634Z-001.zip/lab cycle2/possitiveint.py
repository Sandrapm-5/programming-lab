list1 = [-3, -2, -1, 0, 1, 2, 3, 4]
for pos in list1:
    if pos > 0:
        print("positive numbers are:", pos)
