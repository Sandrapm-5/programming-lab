length = int(input("enter the number of firstnames:"))
counts = 0
for i in range(length):
    a = str(input("enter the name").split(" ")[0])
    counts+= a.count('a')
print(counts)


