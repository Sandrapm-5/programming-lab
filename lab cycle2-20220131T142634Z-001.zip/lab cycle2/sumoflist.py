import math
list1 = [2, 3, 4, 5]
list2 = [2, 3, 5, 4]
if(sum(list1)==sum(list2)):
    print("sum of list and list2", sum(list1), sum(list2))
else:
    print("sum is not equal")
