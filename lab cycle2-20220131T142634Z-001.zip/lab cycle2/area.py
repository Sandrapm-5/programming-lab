pi = 3.14
r = float(input("enter the radius of the circle:"))
area = pi * r * r
print("area a cirle=", area)

