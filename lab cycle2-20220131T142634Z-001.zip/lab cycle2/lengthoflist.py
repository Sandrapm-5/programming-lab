list1 = [1, 2, 3, 4]
list2 = [7, 8, 9]
print(len(list1))
print(len(list2))
if len(list1) == len(list2):

    print("list1 and list2 are of same length")
else:

     print("not equal")