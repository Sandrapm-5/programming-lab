print("value is", ord('A'))
print("value is", ord('b'))
