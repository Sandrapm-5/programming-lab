lower = int(input('enter the lower:'))
upper = int(input('enter the upper'))
for i in range(lower, upper + 1):
    num = 0
    if num > 1:
        continue
    for i in range(2, num):
        if num % i == 0:
            print(num)
        else:
            break
