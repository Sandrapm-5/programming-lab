import math
list1 = [1, 2, 3, 4]
print(list1)
sq = [number ** 2 for number in list1]
print("square of numbers:", sq)

