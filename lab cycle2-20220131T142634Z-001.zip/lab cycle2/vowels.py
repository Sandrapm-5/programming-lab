word1 = input("enter the words:")
word2 = input("enter word:")
if word2 in word1:
    for vowel in word2:
        if vowel[0] in 'aeiou':
            print(list(vowel))
else:
     print("element not found")