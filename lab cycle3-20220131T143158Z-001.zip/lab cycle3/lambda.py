area = lambda x: x**2
print("area of square", area(5))
rectangle = lambda x, y: x*y
print("area of rectangle", rectangle(2, 4))
triangle = lambda b, h: 0.5*b*h
print("area of triangle", triangle(10, 5))
