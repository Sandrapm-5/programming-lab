num = int(input("enter a number:"))

fact = 1
for i in range(num, 0, -1):
    fact = fact* i
print("factorial=", fact)
