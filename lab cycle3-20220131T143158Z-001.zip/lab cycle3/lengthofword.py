def long(a):
    maximum = len(a[0])
    temp = a[0]
    for i in a:
        if len(i) > maximum:
            maximum = len(i)
            temp = i
    print("the word with longest length is", temp,  "and length is", maximum)
    a = ["apple", "orange", "mango"]
    long(a)
