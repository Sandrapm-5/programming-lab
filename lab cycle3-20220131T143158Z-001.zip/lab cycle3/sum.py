list1 = [1, 2, 3, 4]
sum = 0
for i in list1:
    sum = sum+i
    print("sum=", sum)
